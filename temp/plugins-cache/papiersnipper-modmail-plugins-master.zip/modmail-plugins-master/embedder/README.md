<div align="center">
    <img  src="https://i.imgur.com/gBuM0Nz.png" align="center">
    <p><strong><i>Easily make embeds for a nicer look.</i></strong></p>
</div>

## Installation

To use this plugin, use this command in your Modmail server: `plugin add embedder`

## Commands

| name        | usage                    | example                                        | permission    | description                                |
| ----------- | ------------------------ | ---------------------------------------------- | ------------- | ------------------------------------------ |
| embed color | embed color hexcode      | embed #7289DA                                  | Moderator [3] | Send an embed.                             |
| embed send  | embed send title message | embed "Tourney Info" Checkout the new bracket! | Moderator [3] | Save an embed colorcode for future embeds. |

## Permissions

The bot doesn't need additional permissions.
