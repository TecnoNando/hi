<div align="center">
    <img  src="https://i.imgur.com/lWUejZY.png" align="center">
    <p><strong><i>Assign roles using reactions.</i></strong></p>
</div>

## Installation

To use this plugin, use this command in your Modmail server: `plugin add papiersnipper/modmail-plugins/role-assignment`

## Commands

| name        | usage                | example                | permission         | description                                     |
|-------------|----------------------|------------------------|--------------------|-------------------------------------------------|
| role add    | role add emoji role  | role add emoji @Artist | Administrator [4]  | Add a clickable emoji to each new message.      |
| role remove | role remove emoji    | role remove emoji      | Administrator [4]  | Remove a clickable emoji from each new message. |

## Permissions

The bot doesn't need additional permissions.