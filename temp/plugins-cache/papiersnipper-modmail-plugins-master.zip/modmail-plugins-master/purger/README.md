<div align="center">
    <img  src="https://i.imgur.com/8nKlf9K.png" align="center">
    <p><strong><i>Delete multiple messages at a time.</i></strong></p>
</div>

## Installation

To use this plugin, use this command in your Modmail server: `plugin add purger`

## Commands

| name  | usage        | example  | permission    | description                              |
| ----- | ------------ | -------- | ------------- | ---------------------------------------- |
| purge | purge amount | purge 10 | Moderator [3] | Delete the specified amount of messages. |

## Permissions

The bot needs the `manage messages` permission to delete messages.
