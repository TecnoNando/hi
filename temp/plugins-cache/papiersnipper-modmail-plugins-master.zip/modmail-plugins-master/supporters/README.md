<div align="center">
    <img  src="https://i.imgur.com/jnxuYhE.png" align="center">
    <p><strong><i>Let your users know who is part of the support team.</i></strong></p>
</div>

## Installation

To use this plugin, use this command in your Modmail server: `plugin add supporters`

## Commands

| name         | aliases                            | example      | permission   | description                                     |
|--------------|------------------------------------|--------------|--------------|-------------------------------------------------|
| supporters   | helpers, support, supportmembers   | supporters   | Regular [0]  | Send an embed with all of the support members.  |

## Permissions

The bot doesn't need additional permissions.