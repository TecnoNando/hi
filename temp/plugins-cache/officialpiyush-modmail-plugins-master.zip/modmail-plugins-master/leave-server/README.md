<div align="center">
    <img src="https://images.piyush.codes/b/0XgiTdb.png" alt="LS Image" align="center"></img>
    <br>
    <strong><i>A plugin For ModMail Bot to force it to leave a specified server.</i></strong>
   <br>
   <br>

  <a href="https://discord.gg/hzD72GE">
    <img src="https://img.shields.io/discord/543812119397924886.svg?style=for-the-badge&colorB=7289DA" alt="Support">
  </a> 
</div>

---
