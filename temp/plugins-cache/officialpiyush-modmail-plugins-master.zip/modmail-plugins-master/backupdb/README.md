<div align="center">
    <img src="https://images.piyush.codes/b/4XqTtrK.png" alt="BD Image" align="center"></img>
    <br>
    <strong><i>A plugin to backup modmail database.</i></strong>
   <br>
   <br>

  <a href="https://discord.gg/hzD72GE">
    <img src="https://img.shields.io/discord/543812119397924886.svg?style=for-the-badge&colorB=7289DA" alt="Support">
  </a> 
</div>

---