---
name: New plugin
about: I have new plugin idea.
title: "[Plugin Request]"
labels: plugin idea
assignees: ''

---

**Explain your plugin:**

**How is it beneficial:**
