# Calculator

Calculator as a plugin (caap).

## Installation

To add this plugin, use this command in your Modmail server: `?plugin add calculator`.

## Usage

The commands usage list assumes you retain the default prefix, `?`.

| Permission level | Usage | Function | Note |
|------------------|-------|----------|------|